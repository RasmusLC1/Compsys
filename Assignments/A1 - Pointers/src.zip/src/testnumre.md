findes: 1428125 canada
25871341 europe
45 45 northpole