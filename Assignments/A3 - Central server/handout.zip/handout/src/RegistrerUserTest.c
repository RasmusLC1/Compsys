// #include <criterion/criterion.h>

// #include  <criterion/redirect.h>
// #include "../src/networking.h"


// TEST(RegisterUserTest, create){
//     int a = 5;
//     cr_expect(a == 5, "error");
// }