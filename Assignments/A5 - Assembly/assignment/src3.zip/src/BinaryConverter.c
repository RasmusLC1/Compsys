#include "BinaryConverter.h"

int binary2decimal(long long binary) {
  int dec = 0, base = 1, remainder;
  while(binary > 0){
    remainder = binary % 10;
    dec = dec + remainder * base;
    binary = binary / 10;
    base = base * 2;
  }
  printf("in decimal: %d\n", dec);
  return dec;
}


long long array2long(int *binArray, int size){
  long long binNum;
  char *array2Char = malloc(sizeof(char)*size);
  for (int i = 0; i < size; i++){
    array2Char[i] = binArray[i] + '0';
  }
  binNum = atoi(array2Char);
  free(array2Char);
  return binNum;
}


int * decimal2binary(long num){
  static int binaryRev[32], binary[32];
  int i = 0, index = 0;
  while (num > 0) {
    binaryRev[i] = num % 2;
    num = num / 2;
    i++;
  }

  //Adding missing zeros in front
  if (i != 32){
    int missingZeros = 32-i;
    
    for (int i = 0; i < missingZeros; i++){
      binary[i] = 0;
      index++;
    }
  }

  //Reversing, so it is in correct order
  for (int j = i - 1; j >= 0; j--){
    binary[index] = binaryRev[j];
    index++;
  }
  return binary;

	
  
  
}