#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <limits.h>
#include "simulate.h"

int binary2decimal(long long n);

long long array2long(int *binArray, int size);

int * decimal2binary(long n);