#include "Decoder.h"



void i_instruction(long code, int* x_registers, struct memory *mem){
    uint32_t reg_dest = (code >> 7) & RD_MASK;
    uint32_t funct3 = (code >> 12) & FUNCT3_MASK;
    uint32_t rs1 = (code >> 15) & RS1_MASK;
    int imm = 0;  

        imm = (code >> 20) & SIGNEDBIN;
    int instruction;
    switch (funct3){
    case 0:   
        instruction = LB;
        x_registers[reg_dest] = memory_rd_b(mem, x_registers[rs1]+imm);
        break;
    case 1:
        imm = (code >> 20) & SIGNEDBIN;
        x_registers[reg_dest] = memory_rd_h(mem, x_registers[rs1]+imm*2);
        instruction = LH;
        break;
    case 2:
        imm = (code >> 20) & SIGNEDBIN;
        x_registers[reg_dest] = memory_rd_w(mem, imm+x_registers[rs1]);

        instruction = LW;
        break;
    case 4:
        imm = (code >> 20) & UNSIGNEDBIN_12;
        x_registers[reg_dest] = memory_rd_b(mem, imm+x_registers[rs1]);
        instruction = LBU;;
        break;
    case 5:
        imm = (code >> 20) & UNSIGNEDBIN_12;
        x_registers[reg_dest] = memory_rd_h(mem, x_registers[rs1]+imm*2);
        instruction = LHU;
        break;
    default:
        instruction = 99;
        break;
    }
}
void immediate_instruction(long code, int* x_registers){
    uint32_t  reg_dest = (code >> 7) & RD_MASK;
    uint32_t  funct3 = (code >> 12) & FUNCT3_MASK;
    uint32_t  rs1 = (code >> 15) & RS1_MASK;
    uint32_t  funct7 = (code >> 25) & FUNCT7_MASK;
    int  imm = (code >> 20) & UNSIGNEDBIN_12;
    uint32_t bit31 = (code >> 31) & 1;

    if (bit31 == 1) {
        int offset = (code >> 19) & UNSIGNEDBIN_12;
        imm = offset - imm;
    }

    int instruction;
    switch (funct3){
    case 0:
        instruction = ADDI;
        x_registers[reg_dest] = x_registers[rs1] + imm;
        break;
    case 1:
        instruction = SLLI;
        x_registers[reg_dest] = x_registers[rs1] << imm;
        break;
    case 2:             //NOT DONE
        instruction = SLTI;
        
        break;
    case 3:             //NOT DONE
        instruction = SLTIU;
        break;
    case 4:
        instruction = XORI;
        x_registers[reg_dest] = x_registers[rs1] ^ imm;
        break;
    case 5:
        if (funct7 == 0){
            instruction = SRLI;
            x_registers[reg_dest] = x_registers[rs1] >> imm;
            break;
        } else if (funct7 == 32){
            instruction = SRAI;
            break;            
        }
    case 6:
        instruction = ORI;
        x_registers[reg_dest] = x_registers[rs1] | imm;
        break;
    case 7:
        instruction = ANDI;
        x_registers[reg_dest] = x_registers[rs1] && imm;
        break;
    default:
        break;
    }
}

void store_instruction(long code, int* x_registers, struct memory *mem){
    uint32_t rs1 = (code >> 20) & RD_MASK;
    uint32_t funct3 = (code >> 12) & FUNCT3_MASK;
    uint32_t rs2 = (code >> 23) & RS2_MASK;
    uint32_t imm = (code >> 7) & UNSIGNEDBIN_6;
    
    int instruction;
    switch (funct3){
        case 0:
            memory_wr_b(mem, imm+x_registers[rs2], x_registers[rs1]);
            instruction = SB;
            break;
        case 1:
            memory_wr_h(mem, imm+x_registers[rs2], x_registers[rs1]);
            instruction = SH;
            break;
        case 2:
            memory_wr_w(mem, imm+x_registers[rs2], x_registers[rs1]);
            instruction = SW;
            break;
        default:
            break;
    }
}

void register_instruction(long code, int* x_registers){
    uint32_t  reg_dest = (code >> 7) & RD_MASK;
    uint32_t  rs1 = (code >> 15) & RS1_MASK;
    uint32_t  rs2 = (code >> 20) & RS2_MASK;
    uint32_t  funct7 = (code >> 25) & FUNCT7_MASK;
    uint32_t  funct3 = (code >> 12) & FUNCT3_MASK;

    int instruction;
    if (funct7 == 0){
        switch (funct3){
            case 0:
                instruction = ADD;
                x_registers[reg_dest] = x_registers[rs1] + x_registers[rs2]; 
                break;
            case 1:
                instruction = SLL;
                x_registers[reg_dest] = x_registers[rs1] << x_registers[rs2]; 
                break;
            case 4:
                instruction = XOR;
                x_registers[reg_dest] = x_registers[rs1] ^ x_registers[rs2]; 
                break;
            case 5:
                instruction = SRL;
                x_registers[reg_dest] = x_registers[rs1] >> x_registers[rs2]; 
                break;
            case 6:
                instruction = OR;
                x_registers[reg_dest] = x_registers[rs1] | x_registers[rs2];
                break;
            case 7:
                instruction = AND;
                x_registers[reg_dest] = x_registers[rs1] & x_registers[rs2];
                break;
            default:
                break;
        }
    } else if(funct7 == 8){
        instruction = LR_D;
    } else if(funct7 == 12){
        instruction = SC_D;
    } else if(funct7 == 32){
        if (funct3 == 0){
            instruction = SUB;
            x_registers[reg_dest] = x_registers[rs1] - x_registers[rs2];
        } else if (funct3 == 1){
            instruction = SRA; //Needs to be signed to do arithmetic shift
        }
    }
}

void SB_instruction(long code, int* x_registers, struct memory *mem,
int* commands){
   // Defines last 20 bits of instruction code
    uint32_t bit31 = (code >> 31) & 1;
    uint32_t bit31offset;

    if (bit31 == 1) {
        bit31offset = 0xFFFFF000;
    } else {
        bit31offset = 0;
    }

    // Define type of branch condition, and what is to be compared
    uint32_t rs1 = (code >> 15) & RS1_MASK;
    uint32_t rs2 = (code >> 20) & RS2_MASK;
    uint32_t funct3 = (code >> 12) & FUNCT3_MASK;
    uint32_t reg_dest = (code >> 7) & RD_MASK;
    uint32_t funct7 = (code >> 25) & FUNCT7_MASK;

    // Translates instruction to immediate
    int offset = (((code & SB_BIT31) >> 19) |
                 ((code & SB_BIT30_25) >> 20) |
                 ((code & SB_BIT11_8) >> 7) |
                 ((code & SB_BIT7) << 4)) | bit31offset;

    int immediate = 0xFE000F80 | offset;
    int address;
    if (bit31offset == 0) {
        address = commands[0] + offset;
    } else {
        address = commands[0] + immediate;
    }

    printf("PC hex: %x\n", address);

    int instruction;
    switch (funct3) {
        case 0:            
            instruction = BEQ;
            if (x_registers[rs1] == address) {
                commands[0] = address;
            }
            break;
        case 1:
            instruction = BNE;
            if (rs1 != 0) { // maybe needs rs1 != rs2 too
                // PC = PC + offset;
                x_registers[reg_dest] = commands[0];
                break;
            } else if (rs1 != rs2) {
                // PC = PC + offset;
                x_registers[reg_dest] = commands[0];
                break;
            } else {
                if (bit31offset == 0) {
                    commands[0] -= offset;
                } else {
                    commands[0] -= immediate;
                }
                break;
            }
            break;
        case 4:
            instruction = BLT;
            if (rs1 < rs2) {
                x_registers[reg_dest] = commands[0];
                break;
            } else {
                if (bit31offset == 0) {
                    commands[0] -= offset;
                } else {
                    commands[0] -= immediate;
                }
                break;
            }
            break;
        case 5:
            instruction = BGE;
            if (rs1 >= rs2) {
                x_registers[reg_dest] = commands[0];
                break;
            } else {
                if (bit31offset == 0) {
                    commands[0] -= offset;
                } else {
                    commands[0] -= immediate;
                }
                break;
            }
            break;
        case 6:
            instruction = BLTU;
            break;
        case 7:
            instruction = BGEU;
            break;
        default:
            break;
        }
}

void m_instruction(long code, int* x_registers){
    uint32_t  reg_dest = (code >> 7) & RD_MASK;
    uint32_t  funct3 = (code >> 12) & FUNCT3_MASK;
    uint32_t  rs1 = (code >> 15) & RS1_MASK;
    uint32_t  rs2 = (code >> 20) & RS2_MASK;
    uint32_t  funct7 = (code >> 25) & FUNCT7_MASK;

    int instruction;
    switch (funct3) {
    case 0:
        instruction = MUL;
        x_registers[reg_dest] = x_registers[rs1] * x_registers[rs2];
        return;
    case 1:
        instruction = MULH;
         x_registers[reg_dest] = x_registers[rs1] * x_registers[rs2];
        return;
    case 2:
        instruction = MULHSU; //Unsigned
         x_registers[reg_dest] = x_registers[rs1] * x_registers[rs2];
        return;
    case 3:
        instruction = MULHU; //Unsigned
         x_registers[reg_dest] = x_registers[rs1] * x_registers[rs2];
        return;
    case 4:             
        instruction = DIV;
         x_registers[reg_dest] = x_registers[rs1] / x_registers[rs2];
        return;
    case 5:
        instruction = DIVU; //Unsigned
        x_registers[reg_dest] = x_registers[rs1] / x_registers[rs2];
        return;
    case 6:             //NOT DONE
        instruction = REM;
        x_registers[reg_dest] = x_registers[rs1] % x_registers[rs2]; 
        return;
    case 7:
        instruction = REMU; //Unsigned
        x_registers[reg_dest] = x_registers[rs1] % x_registers[rs2]; 
        return;
    default:
        return;
    }
    return;
}


void ecall_instruction(int* x_registers){
    // printf("test %d\n", x_registers[17]);
    int i = 0;
    char *test;
    int ch;
    
    switch (x_registers[17]) {
        case 1:
            x_registers[17] = getchar();
            break;
        case 2:
            putchar(x_registers[16]);
            break;
        case 3:
            x_registers[33] = 1;
            break;
        case 93:
            x_registers[33] = 1;
            break;
        default:
            printf("TESTOSDGJISG, %d\n", x_registers[17]);
            break;
    }
}

