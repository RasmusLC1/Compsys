#include "simulate.h"




// Simuler RISC-V program i givet lager og fra given start adresse
long int simulate(struct memory *mem, struct assembly
*as, int start_addr, FILE *log_file) {
    int x_registers[33] = {0};
    int commands[10] = {0};
    commands[0] = start_addr;
    
    FILE *f = fopen("hello.txt", "a");
    // Get start address and first instruction
    int i = 0;
    while (1){
        // printf("TESDGPKSG %x\n", commands[0]);
        commands[0] += 4;
        long instruction = memory_rd_w(mem, commands[0]);
        char *command = assembly_get(as, commands[0]);
        printf("%s\n", command);
        instruction_decoder(instruction, x_registers, mem, commands);
        // printf("A0 TRACKER %d\n\n", x_registers[10]);
        if (x_registers[33] == 1){
            printf("tse\n\n");
            break;
        }
    }
    // for (int i = 0; i < 32; i++){
    //     printf("command %d: %d\n", i, x_registers[i]);
    // }
    return 10;
    
}

void instruction_decoder(long instruction, int *x_registers,
struct memory *mem, int *commands) {
    uint32_t  OPCode = instruction & OP_MASK;
    uint32_t  funct7 = (instruction >> 25) & FUNCT7_MASK;

    int command;
    switch (OPCode){
        case I_TYPE:
            i_instruction(instruction, x_registers, mem);
            return;
        case IMMEDIATES:
            immediate_instruction(instruction, x_registers);
            return;
        case S_TYPE:
            store_instruction(instruction, x_registers, mem);
            return;
        case R_TYPE:
            if (funct7 == 1){
                m_instruction(instruction, x_registers);
            } else{
                register_instruction(instruction, x_registers);
            }
            return;
        case SB_TYPE:
            SB_instruction(instruction, x_registers, mem, commands);
            return;
    }

    //Transition to if statement to instantiate variables
    if (OPCode == U_TYPE){
        uint32_t reg_dest =  (instruction >> 7) & RD_MASK;
        uint32_t imm = instruction >> 12;
        x_registers[reg_dest] = (imm << 12) & LUI_OFFSET;
        printf("%d\n", reg_dest);
        printf("x_registers[reg_dest] %d\n", x_registers[reg_dest]);
        // LUI
    } else if (OPCode == UJ_TYPE){  //PRINTING SHARES SPOT WITH JAL, NEED TO DIFFERENTIATE
        
        uint32_t reg_dest = (instruction >> 7) & RD_MASK;
        uint32_t  imm2 = (instruction >> 20) & SIGNEDBIN;
        uint32_t  funct7 = (instruction >> 25) & FUNCT7_MASK;
        uint32_t offset = (((instruction & JAL1912) >> 20) |
            ((instruction & JAL11) >> 9) |
            (instruction & JAL101) |
            ((instruction & JAL20) >> 13));
        int imm = JAL_COMPLEMENT | offset;
        int addr = commands[0] + imm - 4;
        x_registers[reg_dest] = commands[0];
        commands[0] = (addr & JAL_PC);
        printf("commands %x\n", commands[0]);
        // exit(0);
        return;

// uint32_t offset = (((instruction & JAL1912) >> 20) |
//             ((instruction & JAL11) >> 9) |
//             (instruction & JAL101) |
//             ((instruction & JAL20) >> 13));
//         uint32_t imm = JAL_COMPLEMENT | offset;
//         uint32_t addr = commands[0] + imm - 4;
// 11111111111111111111000000000000




    } else if (OPCode == JALR){
        uint32_t reg_dest = (instruction >> 7) & RD_MASK;
        uint32_t  rs1 = (instruction >> 15) & RS1_MASK;
        uint32_t  imm = (instruction >> 20) & SIGNEDBIN;
        // imm = imm & UNSIGNEDBIN_12;
        
        uint32_t addr = commands[0] + imm;
        commands[0] = x_registers[rs1];
        x_registers[rs1] = addr;
        printf("addr %x\n", addr);
        printf("rs1 %d\n", rs1);
        printf("IMM VALUE %d\n", imm);
        printf("REGDEST VALUE %d\n", reg_dest);
        printf("INSTRUCTIONS VALUE %x\n", instruction);
        printf("commands[0] %x\n", commands[0]);
        printf("x_registers[reg] %x\n", x_registers[reg_dest]);
        printf("x_registers[rs1] %x\n", x_registers[rs1]);
        return;
    } else if (OPCode == LEFTOVER){
        ecall_instruction(x_registers);
    } else{
        printf("\n\nINVALID INSTRUCTION %d\n", OPCode);
         uint32_t  reg_dest = (instruction >> 7) & RD_MASK;
        uint32_t  funct3 = (instruction >> 12) & FUNCT3_MASK;
        uint32_t  rs1 = (instruction >> 15) & RS1_MASK;
        uint32_t  imm = (instruction >> 20) & SIGNEDBIN;
        printf("reg_dest %d\n", reg_dest);
        printf("funct3 %d\n", funct3);
        printf("rs1 %d\n", rs1);
        printf("imm %d\n", imm);
        printf("x7aegistrer %d\n", x_registers[17]);
        exit(EXIT_FAILURE);
    }
}