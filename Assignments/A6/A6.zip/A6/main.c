#include "memory.h"
#include "cache.h"
#include <stdio.h>
#include <stdlib.h>
//#include <string.h>
// #include <time.h>

int main(int argc, char *argv[])
{
    int W = atoi(argv[1]);
    printf("W to int is: %d\n", W);
    int S = atoi(argv[2]);
    printf("S to int is: %d\n", S);
    long long B = atoi(argv[3]);
    printf("B to int is: %lld \n", B);
    struct memory *mem = memory_create();

    struct cache* new_cache = cache_create(W, S, B, mem);
    
    // WHERE DO WE GET OUR op, addr, data FROM????
    char op;
    int addr;
    long data;

    while(1) {
        printf("Enter \"op addr data\" or several lines like that: \n");
        scanf("%c %d %ld", &op, &addr, &data); fflush(stdout);
            if (op == 'i') {
                init(mem, addr, data, op);
            } else if (op == 'r' && (addr % 4 == 0)) {
                cache_read(new_cache, addr, op);
            } else if (op == 'w' && (addr % 4 == 0)) {
                cache_write(new_cache, addr, data, op);
            } else {
                printf("ERROR: The written op \"%c\" is an invalid input\n", op);
            }
            //struct assembly *as = assembly_create();
            //FILE *log_file = NULL;
            // if (argc == 3 && !strcmp(argv[2], "-l"))
            // {
            //     log_file = fopen(argv[3], "w");
            //     if (log_file == NULL)
            //     {
            //         terminate("Could not open logfile, terminating.");
            //     }
            // }
            
            //int start_addr = read_exec(mem, as, argv[1], log_file);
            // clock_t before = clock();
            // long int num_insns = simulate(mem, as, start_addr, log_file);
            // clock_t after = clock();
            // int ticks = after - before;
            // double mips = (1.0 * num_insns * CLOCKS_PER_SEC) / ticks / 1000000;
            // if (argc == 4 && !strcmp(argv[2], "-s"))
            // {
            //     log_file = fopen(argv[3], "w");
            //     if (log_file == NULL)
            //     {
            //         terminate("Could not open logfile, terminating.");
            //     }
            // }

            // if (log_file)
            // {
            //     fprintf(log_file, "\nSimulated %ld instructions in %d ticks (%f MIPS)\n", num_insns, ticks, mips);
            //     fclose(log_file);
            // } else
            // {
            //     printf("\nSimulated %ld instructions in %d ticks (%f MIPS)\n", num_insns, ticks, mips);
            // }
            //assembly_delete(as);

            // op addr data INIT
            // op addr data HIT lru-order
            // op addr data FILL lru-order
            // op addr data EVICT lru-order
            // op addr data DISCARD lru-order
    }
    memory_delete(mem);
    cache_delete(new_cache);
}
