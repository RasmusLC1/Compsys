TBL:
Insert the TBL from assignment in the TBL.txt and santise the data, so remove the
set in front and make sure there are no spaces in front

PAGETABLE:
Insert the pagetable from assignment in the pageTable.txt and do the same sanitizing as with TBL, see example below:

OLD:
1B 15 1 11 00 0 0A 01 1 04 00 1
1 0B 10 0 0F 10 1 1F 2F 0 00 00 0
2 12 34 1 1A 01 0 0D 00 0 00 00 1
3 0B 15 1 0B 02 0 1A 0A 1 1F 3F 1

SANITISED:
1B 15 1
11 00 0
0A 01 1
04 00 1
0B 10 0
0F 10 1
1F 2F 0
00 00 0
12 34 1
1A 01 0
0D 00 0
00 00 1
0B 15 1
0B 02 0
1A 0A 1
1F 3F 1

write make and follow the instructions