#include <stdio.h>

int partition(int *array, int p, int r) {
    int pivot = array[p];
    int i=p-1;
    int j=r;
    while (1) {
        do { j--; } while (pivot < array[j]);
            do { i++; } while (array[i] < pivot);
                if (i < j) {
                    int tmp = array[i];
                    array[i] = array[j];
                    array[j] = tmp;
                } else {
                    return j+1;
                }
    }
}

int main(){
    int test[] = {3, 2, 4, 8, 7};  
    int result;
    result = partition(test, 6, 5);
    printf("You entered: %d", result);
    return 1;
}


