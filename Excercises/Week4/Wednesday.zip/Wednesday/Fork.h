int fork1();
int fork2();
int forkHello();
int forkFile();