#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include "Exec.h"
#include "Fork.h"


int main (int argc, char *argv[]) {
    // int x = 200;
    int c = fork1();
    return c;
}
